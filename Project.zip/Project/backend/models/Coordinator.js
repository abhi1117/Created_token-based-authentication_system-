const mongoose = require('mongoose');
const { Schema } = mongoose;

const coordinatorSchema = new Schema({
    admin:{
        type : mongoose.Schema.Types.ObjectId,
        ref : 'admin'
     },
  
    empid : {
    type : Number,
    required : true
   },
   name : {
    type : String,
    required : true
   },
   Password : {
    type : String,
    required : true
   }

  });

  module.exports = mongoose.model('coordinator', coordinatorSchema);