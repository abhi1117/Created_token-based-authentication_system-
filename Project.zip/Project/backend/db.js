const mongoose = require('mongoose');



 function main() {
  mongoose.connect('mongodb://127.0.0.1:27017/centraldb');
  console.log("Connected to Mongodb Sucessfully");
}
module.exports = main;
