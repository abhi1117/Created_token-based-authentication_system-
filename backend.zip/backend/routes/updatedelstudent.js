const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
var fetchfaculty = require("../middleware/fetchFaculty");
const Students = require("../models/Students");
const bcrypt = require("bcryptjs");
var jwt = require("jsonwebtoken");

// Route 1 : Get all the students, Login required
router.get("/fetchallstudents", fetchfaculty, async (req, res) => {
  try {
    const students = await Students.find({ faculty: req.faculty.id });
    res.json(students);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

// Route 2 : Add students using post, Login required
router.post(
  "/addstudents",
  fetchfaculty,
  [
    body("rollNo", "Enter a valid rollNo").isInt(),
    body("name", "Enter a valid name").isLength({ min: 3 }),
    body("Password", "Enter a valid password").isLength({ min: 3 }),
    body("attendence", "Enter valid attendence").notEmpty(),
    body("sub1", "Enter valid marks").notEmpty(),
    body("sub2", "Enter valid marks").notEmpty(),
    body("sub3", "Enter valid marks").notEmpty(),
  ],
  async (req, res) => {
    try {
      const { rollNo, name, Password, attendence, sub1, sub2, sub3 } = req.body;
      // If there is are errors, return bad request and the errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      let student = await Students.findOne({ rollNo: req.body.rollNo });
      if (student) {
        return res
          .status(400)
          .json({
            error: "Sorry a student with this rollnumber already exists",
          });
      }

      const salt = await bcrypt.genSalt(10);
      const secPass = await bcrypt.hash(req.body.Password, salt);

      // add a new student

      student = new Students({
        rollNo,
        name,
        Password: secPass,
        attendence,
        sub1,
        sub2,
        sub3,
        faculty: req.faculty.id,
      });
      const savedStudent = await student.save();

      res.json(savedStudent);
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
  }
);

//Route 3 Update an existing student data using put. login required.
router.put("/updatestudent/:id", fetchfaculty, async (req, res) => {
  const { rollNo, name, Password, attendence, sub1, sub2, sub3 } = req.body;
  try {
    //Create a newnote object

    const newstud = {};
    if (rollNo) {
      newstud.rollNo = rollNo;
    }
    if (name) {
      newstud.name = name;
    }
    if (Password) {
      newstud.Password = Password;
    }
    if (attendence) {
      newstud.attendence = attendence;
    }
    if (sub1) {
      newstud.sub1 = sub1;
    }
    if (sub2) {
      newstud.sub2 = sub2;
    }
    if (sub3) {
      newstud.sub2 = sub3;
    }

    //Find the student and update it
    let stud = await Students.findById(req.params.id);
    if (!stud) {
      return res.status(404).send("Not Found");
    }

    if (stud.faculty.toString() !== req.faculty.id) {
      return res.status(401).send("Not Allowed");
    }

    stud = await Students.findByIdAndUpdate(
      req.params.id,
      { $set: newstud },
      { new: true }
    );
    res.json({ stud });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

//Route 4 delete an existing student data using delete. login required.
router.delete("/deletestudent/:id", fetchfaculty, async (req, res) => {
  const { rollNo, name, Password, attendence, sub1, sub2, sub3 } = req.body;
  try {
    //Find the student and delete it
    let stud = await Students.findById(req.params.id);
    if (!stud) {
      return res.status(404).send("Not Found");
    }

    // allow deletion if user owns this stud
    if (stud.faculty.toString() !== req.faculty.id) {
      return res.status(401).send("Not Allowed");
    }

    stud = await Students.findByIdAndDelete(req.params.id);
    res.json({ Success: "student data has been deleted", stud: stud });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

module.exports = router;
