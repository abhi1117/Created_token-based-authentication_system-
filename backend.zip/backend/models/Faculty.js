const mongoose = require('mongoose');
const { Schema } = mongoose;

const facultySchema = new Schema({
    coordinator:{
        type : mongoose.Schema.Types.ObjectId,
        ref : 'coordinator'
     },
  
    empid : {
    type : Number,
    required : true
   },
   name : {
    type : String,
    required : true
   },
   Password : {
    type : String,
    required : true
   },
   subject : {
    type : String,
    required : true
   }

  });

  module.exports = mongoose.model('Faculty', facultySchema);