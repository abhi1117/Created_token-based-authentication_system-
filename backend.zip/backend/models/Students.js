const mongoose = require('mongoose');
const { Schema } = mongoose;

const studentSchema = new Schema({
   faculty:{
      type : mongoose.Schema.Types.ObjectId,
      ref : 'Faculty'
   },

   rollNo : {
    type : Number,
    required : true,
   },
   name : {
    type : String,
    required : true
   },
   Password : {
    type : String,
    required : true
   },
   attendence : {
    type : Number,
    required : true
   },
   sub1 : {
      type : Number,
    required : true
   },
   sub2 : {
      type : Number,
    required : true
   },
   sub3 : {
      type : Number,
    required : true
   }

  });

  const Students = mongoose.model('students', studentSchema);
  //Students.createIndexes();
  module.exports = Students;